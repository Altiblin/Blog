<?php

return [
	'framework' => 'bootstrap-5',
];