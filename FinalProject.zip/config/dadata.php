<?php

return [
    'token' => env('DADATA_TOKEN'),
    'secret' => env('DADATA_SECRET')
];