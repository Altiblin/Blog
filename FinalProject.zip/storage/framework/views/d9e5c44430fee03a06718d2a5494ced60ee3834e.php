<?php foreach($attributes->onlyProps([
    'comments'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'comments'
]); ?>
<?php foreach (array_filter(([
    'comments'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-success">
        <em><?php echo e($comment->created_at); ?></em>
        <div class="mt-2"><?php echo e($comment->text); ?></div>
        <a href="<?php echo e(route('comments.edit', [ $comment->id ])); ?>">Исправить</a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\web\lessongt5\resources\views/components/comments/list.blade.php ENDPATH**/ ?>