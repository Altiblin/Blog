<?php foreach($attributes->onlyProps([
    'title'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title'
]); ?>
<?php foreach (array_filter(([
    'title'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css\app.css', 'resources/js/app.js']); ?>
</head>
<body class="app-grid">
    <header>
        <div class="container py-3 mb-4 border-bottom">
            header
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('login.exit')); ?>">Logout</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Login</a>
            <?php endif; ?>
        </div>
    </header>
    <div>
        <div class="container">
            <div class="row">
                <div class="col col-12 col-md-3">
                    <ul class="nav nav-pills flex-column mb-auto">
                        <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('home')); ?>" class="nav-link link-dark">Главная</a>
                        </li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-tags')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('tags.index')); ?>" class="nav-link link-dark">Теги</a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('posts.index')); ?>" class="nav-link link-dark">Блог</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('videos.index')); ?>" class="nav-link link-dark">Видео</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('profile.password.edit')); ?>" class="nav-link link-dark">Смена пароля</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('address.form')); ?>" class="nav-link link-dark">Анализ адреса</a>
                        </li>
                        <?php else: ?>
                        <li>
                            <a href="<?php echo e('/'); ?>" class="nav-link link-dark">Блог</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <main class="col col-12 col-md-9">
                    <?php if(!auth()->user()->email_verified_at): ?>
                        <div class="alert alert-danger">Подтверди почту!!!!</div>
                    <?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.notifications','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notifications'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <h1 class="h3 mb-4"><?php echo e($title); ?></h1>
                    <?php echo e($slot); ?>

                </main>
            </div>
        </div>
    </div>
    <footer class="py-3 m4-3 border-top">
        <div class="container">
            footer
        </div>
    </footer>
</body>
</html><?php /**PATH D:\web\lessongt5\resources\views/components/layouts/base.blade.php ENDPATH**/ ?>