<?php if($label): ?>
    <label <?php echo $attributes; ?>><?php echo e($label); ?></label>
<?php endif; ?><?php /**PATH D:\web\lessongt5\vendor\protonemedia\laravel-form-components\src\Support/../../resources/views/bootstrap-5/form-label.blade.php ENDPATH**/ ?>