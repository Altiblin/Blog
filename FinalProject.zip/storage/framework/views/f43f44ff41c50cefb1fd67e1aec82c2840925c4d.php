<?php
// class component
$message = session()->get('notification');
$hasMessage = $message !== null;
$messages = $hasMessage ? config('app-notifications') : [];

?>

<?php if($hasMessage): ?>
<div class="mb-4 alert alert-<?php echo e($messages[$message]['type']); ?> ">
    <?php echo e($messages[$message]['text']); ?>

</div>
<?php endif; ?><?php /**PATH D:\web\lessongt5\resources\views/components/notifications.blade.php ENDPATH**/ ?>