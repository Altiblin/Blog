<div class="mb-3">
    <x-form-input name="code" label="Код ютуба" /> 
</div>