<div class="mb-3">
    <x-form-input name="title" label="Заголовок" /> 
</div>
<div class="mb-3">
    <x-form-input name="url" label="Url" />
</div>
<div class="mb-3">
    <x-form-textarea name="description" label="Описание" />
</div>