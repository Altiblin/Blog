<x-layouts.base title="Create new post">
    <div class="alert alert-info">
        Привет! Меню слева поможет ориентироваться.
    </div>
</x-layouts.base>