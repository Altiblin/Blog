<x-layouts.base title="Результат">
    
</x-layouts.base>