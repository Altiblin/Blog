import 'bootstrap/dist/css/bootstrap.css'

console.log('hi!');