<?php

return [
    'failed' => 'Данные не совпадают'
];