<?php

return [
    'previous' => 'Назад',
    'next' => 'Вперёд'
];